const data = require("./db");

module.exports = {
    dbfunction: data
};